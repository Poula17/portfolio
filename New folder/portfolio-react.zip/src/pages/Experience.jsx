function Experience() {
  return (
    <div>
      <h2 className="text-xl font-bold mb-4">Experience</h2>
      <ul className="list-disc list-inside">
        <li>Digital Egypt Pioneers (Infrastructure Track)</li>
        <li>Red Nexus (Red Teaming Course)</li>
        <li>ITI Summer Training</li>
      </ul>
    </div>
  )
}

export default Experience