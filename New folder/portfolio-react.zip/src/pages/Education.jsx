function Education() {
  return (
    <div>
      <h2 className="text-xl font-bold mb-4">Education</h2>
      <p>Bachelor of Computer Engineering and Science</p>
      <p>Faculty of Electronic Engineering, Menouf</p>
      <p>Expected Graduation: 2026</p>
    </div>
  )
}

export default Education